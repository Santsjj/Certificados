'use strict';
//Redireccionamientos a otras páginas
//Redes sociales de la Universidad
//WhatsApp
function redirigir01(){
    window.location.href="https://api.whatsapp.com/send?phone=573107836734&text=Hola!%20Quiero%20informaci%C3%B3n%20de%20la%20universidad.";
}
//Instagram
function redirigir02(){
    window.location.href="https://www.instagram.com/uniempresarial/";
}
//Facebook
function redirigir03(){
    window.location.href="https://www.facebook.com/uniempresarial";
}
//Twitter
function redirigir04(){
    window.location.href="https://twitter.com/uempresarial";
}
//Email
function redirigir05(){
    window.location.href="https://login.microsoftonline.com/login.srf";
}
//Página Principal
function redirigir06(){
   window.location.href="../index.html";
}
//Cambio de Contraseña
function redirigir07(){
    window.location.href="../Certificado-main/CContraseña.html";
 }
//Historial
function redirigir08(){
    window.location.href="../Certificado-main/Historial.html";
}
//Usuarios Registrados
function redirigir09(){
    window.location.href="../Certificado-main/URegistrados.html";
}
//Generar certificados
function redirigir10(){
    window.location.href="../Certificado-main/certificadoAdmin.html";
}
//Editar salarios
function redirigir11(){
    window.location.href="../Certificado-main/ESalario.html";
}
//Agregar Usuario
function redirigir12(){
    window.location.href="../Certificado-main/agregarUsuario.html";
}