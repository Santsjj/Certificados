<?php
//conexión base de datos
   $con = mysqli_connect('localhost:3307','root','','certificados');
//    $con = mysqli_connect('localhost','root','','certificados');
    if ($con){

    }
    else{
        die("No se puedo conectar");
    }
?>